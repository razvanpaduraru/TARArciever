#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#define MAX 100
#define SEPARATORS " \n"

/* definirea structurilor folosite*/

// structura pentru citirea comenzii
typedef struct cmd{
		char *cmd; // main command
		char *args[2]; // char arguments
}COMMAND;


//structura pentru un fisier ce va fi scris in arhiva
typedef union record {
		char charptr[512];
		struct header {
				char name[100];
				char mode[8];
				char uid[8];
				char gid[8];
				char size[12];
				char mtime[12];
				char chksum[8];
				char typeflag;
				char linkname[100];
				char magic[8];
				char uname[32];
				char gname[32];
				char devmajor[8];
				char devminor[8];
		} header;
}RECORD;


// functie pentru prelucrarea comenzilor primite din terminal
void read_command(COMMAND *cmd){
		char input[MAX], *token;
		int idx = 0;

		fgets(input,MAX,stdin);
		token=strtok(input, SEPARATORS);

		while (token != NULL) {
				if (idx == 0) {
						cmd->cmd = strdup(token);
				} else {
					   cmd->args[idx-1] = strdup(token);
				}
				idx++;
				token=strtok(NULL, SEPARATORS);
		}

}

// functie pentru parsarea stringului cu permisiuni si calcularea acestora
int check_permissions(char mode[10]){
	int user = 0, group = 0, others = 0;

	if (mode[1]=='r') {
		user+=4;
	}
	if(mode[2]=='w') {
		user+=2;
	}
	if(mode[3]=='x') {
		user+=1;
	}
	if(mode[4]=='r') {
		group+=4;
	}
	if(mode[5]=='w') {
		group+=2;
	}
	if(mode[6]=='x') {
		group+=1;
	}
	if(mode[7]=='r') {
		others+=4;
	}
	if(mode[8]=='w') {
		others+=2;
	}
	if(mode[9]=='x'){
		others+=1;
	}

	return user*100+group*10+others;
}

// functie pentru conversia timpului in secunde
int convert_time(int day, int month, int year, int hour, int min, double sec){
	struct tm date;

	date.tm_year = year - 1900;
  date.tm_mon = month - 1;
  date.tm_mday = day;
  date.tm_hour = hour;
  date.tm_min = min;
  date.tm_sec = (int)sec;
  date.tm_isdst = -1;

  return (int)mktime(&date);
}

// functie pentru obtinerea uid-ului din fisierul usermap.txt
// primeste ca parametru linia din fisier corespunzatoare utilizatorului cautat
int get_uid(char input[512]){
	char *token;
	int idx = 0;

	token=strtok(input,":");

	while (token != NULL) {
		if (idx == 2) {
			return atoi(token);
		}
		idx++;
		token=strtok(NULL,":");
	}

	return 0;
}

int get_gid(char input[512]){
	char *token;
	int idx = 0;

	token=strtok(input,":");

	while (token != NULL) {
		if (idx == 3) {
			return atoi(token);
		}
		idx++;
		token=strtok(NULL,":");
	}

	return 0;
}

// functie de conversie a unui numar din baza 8 in baza 10
int octal_to_decimal(int octal) {
	int decimal = 0, digit, idx=0;

	while (octal != 0) {
		digit = octal%10;
		decimal += digit*pow(8, idx);
		idx++;
		octal /= 10;
	}

	return decimal;
}

// functie care returneaza numarul de blocuri de 512 caractere
int get_blocks_no(char size[12]){
	int block_size = 0; 
	
	block_size = atoi(size);
	block_size = octal_to_decimal(block_size);
	return (int)(block_size/512);
}

// scrie fisierul in arhiva
void write_to_archive(RECORD record, FILE *archive) {
	int block_size = 0, i;
	char c;
	//deschidem fisierul pe care trebuie sa-l scriem in arhiva
	FILE *file = fopen(record.header.name, "r");
	//verificare daca fisierul a fost gasit
	if (file == NULL) {
		printf("Fisier inexistent!\n");
		exit(-1);
	}

	block_size = atoi(record.header.size);
	block_size = octal_to_decimal(block_size);
	//scriem record-ul primit ca parametru in arhiva
	fwrite(&record, sizeof(record), 1, archive);

	c = fgetc(file);
	
	do {
	 	fputc(c, archive);
	 	c = fgetc(file);
	} while(!feof(file));

	// verifica daca blocul este umplut si umple
	if ((block_size % 512) != 0) {
		block_size = 512 - (block_size % 512);
		for (i=0; i<block_size; i++) {
			fputc(0, archive);
		}
	}

	fclose(file);
}

// functie pentru comanda "load archivename"
int load(char *archivename){
	FILE *usermap, *file_ls, *archive;
	char tmp[512], *bkp;
	int i, size, day, month, year, hour, min;
	long chksum=0;
	double sec;
	char mode[10];
	RECORD rec;

	usermap=fopen("usermap.txt", "r");
	file_ls=fopen("file_ls", "r");
	//verificam daca exista fisierele cerute
	if(usermap == NULL || file_ls == NULL) {
		printf("One of the required files (usermap.txt and/or file_ls) could not be found.\n");
		return -1;
	} 
	//cream fisierul arhiva
	archive=fopen(archivename,"wb");
	// pozitionare la inceputul fisierului file_ls
	// in care exista lista de fisiere pe care trebuie sa o scriem
	fseek(file_ls,0,SEEK_SET);
	
	while(!feof(file_ls)){
		chksum = 0;
		memset(&rec, 0, sizeof(RECORD));
		// parcurgere linii fisier file_ls
		fscanf(file_ls, "%s\t", mode);
		sprintf(rec.header.mode,"%d",check_permissions(mode));
		//parsam fiecare linie din fisier si completam structura RECORD aferenta
		fseek(file_ls,2,SEEK_CUR);
		
		fscanf(file_ls, "%s\t%s\t%d\t", rec.header.uname, rec.header.gname, &size);
		sprintf(rec.header.size, "%o", size);
		
		fscanf(file_ls, "%d-%d-%d\t%d:%d:%lf\t", &year, &month, &day, &hour, &min, &sec);
    sprintf(rec.header.mtime,"%o",convert_time(day, month, year, hour, min, sec));
		
		fseek(file_ls,6,SEEK_CUR);
		
		fscanf(file_ls, "%s\n", rec.header.name);
		strcpy(rec.header.linkname, rec.header.name);
		rec.header.typeflag = '0';
		strcpy(rec.header.magic, "GNUtar ");

		// cautam uid si guid in fisierul usermap.txt
		fseek(usermap,0,SEEK_SET);
		
		while (fgets(tmp, 512, usermap) != NULL) {
			if((strstr(tmp, rec.header.uname)) != NULL) {
				break;
			}
		}

		bkp = strdup(tmp);
		sprintf(rec.header.uid,"%o",get_uid(tmp));
		sprintf(rec.header.gid,"%o",get_gid(bkp));
		//conform documentatiei:
		//The chksum field is a checksum of all the bytes in the header, assuming that the chksum field itself is all blanks.
		strcpy(rec.header.chksum, "        ");

		for(i=0; i<512; i++){
			chksum += rec.charptr[i];
		}

		sprintf(rec.header.chksum, "%lo", chksum);
		//apelam functia pentru scriere in arhiva
		write_to_archive(rec, archive);
	}

	fclose(usermap);
	fclose(file_ls);
	fclose(archive);

	return 0;   
}

// functie pentru comanda "list archivename"
void list(char *archivename){
	FILE *archive;
	RECORD rec;
	int block_size = 0;
	// deschidem arhiva si parcurgem fiecare inregistrare
	// si scriem numele fisierului
	archive = fopen(archivename,"rb");

	while(fread(&rec, sizeof(RECORD), 1, archive)){
		printf("%s\n", rec.header.name);
		
		block_size = get_blocks_no(rec.header.size);
		
		fseek(archive, 512*++block_size, SEEK_CUR);
	}

	fclose(archive);
}

// functie pentru comanda "get archivename filename"
void get(char *archivename, char *filename){
	FILE *archive;
	RECORD rec;
	char c;
	int block_size = 0, i = 0;
	//deschidem arhiva si cautam numele fisierului cerut
	archive = fopen(archivename,"rb");

	while(fread(&rec, sizeof(RECORD), 1, archive)){
		block_size = atoi(rec.header.size);
		block_size = octal_to_decimal(block_size);

		if (strcmp(rec.header.name, filename) == 0) {
			// am gasit fisierul cautat si
			// incepem sa afisam continutul
			for (i=0; i<block_size; i++) {
				c = fgetc(archive);
				printf("%c", c);
			}
			//vedem daca blocul este complet sau nu
			// calculeaza pasul fseek
			if (block_size % 512) {
				fseek(archive, 512 - (block_size % 512), SEEK_CUR);
			}
		} else {
			i = block_size + 512 - (block_size % 512);
			fseek(archive, i, SEEK_CUR);
		}
	}

	fclose(archive);
}

int main(){
	COMMAND cmd;
   
	while (1) {
		// citirea comenzii
		read_command(&cmd);

		//verifica comanda primita si apeleaza functia corespunzatoare
		if (strcmp(cmd.cmd,"load") == 0) {
			// apelare functie pentru "load archivename"
			load(cmd.args[0]);
		}
		if (strcmp(cmd.cmd,"list") == 0) {
			// apelare functie pentru "list archivename"
			list(cmd.args[0]);
		}
		if (strcmp(cmd.cmd,"get") == 0) {
			// apelare functie pentru "get archivename filename"
			get(cmd.args[0], cmd.args[1]);
		}
		if (strcmp(cmd.cmd,"quit") == 0) {
			break;       
		}
	
	}

	return 0;
}
